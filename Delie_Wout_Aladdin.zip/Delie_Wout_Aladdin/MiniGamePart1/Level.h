#pragma once
#include <Vector2f.h>
#include <vector>

class Texture;
class Platform;
class Sprite;
class SoundStream;

class Level final
{
public:
	Level();
	~Level();
	Level(const Level& other) = delete;
	Level& operator=(const Level& rhs) = delete;
	Level(Level&& other) = delete;
	Level& operator=(Level&& rhs) = delete;

	void DrawBackground()const;
	void DrawForeground()const;

	void HandleCollision(Rectf& actorShape, Vector2f& actorVelocity)const ;
	bool IsOnGround(const Rectf& actorShape, Vector2f& actorVelocity)const;
	void HandleWallCollision(Rectf& actorShape, Vector2f& actorVelocity)const;
	void HandleHeadCollision(Rectf& actorShape)const;
	bool HandleRopeCollision(Rectf& actorShape)const;
	bool HandleFireCollision(const Rectf& actorShape)const;
	bool HandleBeamCollision(Rectf& actorShape)const;

	Rectf GetBoundaries()const;
	bool HasReachedEnd(const Rectf& actorShape)const;
	void PlaySound();
	void ProcessKeyDownEvent( const SDL_KeyboardEvent& e );

private:
	std::vector<std::vector<Point2f>> m_Vertices;
	std::vector<std::vector<Point2f>> m_RopeVertices;
	std::vector<std::vector<Point2f>> m_FireVertices;
	std::vector<std::vector<Point2f>> m_FrontStairsVertices;
	std::vector<std::vector<Point2f>> m_BackStairsVertices;
	std::vector<std::vector<Point2f>> m_BeamVertices;

	const Texture* m_pBackgroundTexture;
	const Texture* m_pForegroundTexture;

	std::vector<Platform*> m_pPlatforms;
	Rectf m_Boundaries;

	Point2f m_PosFire;
	//Sprite* m_pFireSprite;
	
	SoundStream* m_pBackgroundMusic;

	//const Texture* m_pEndSignTexture;
	//Rectf m_EndSignShape;
};

