#pragma once
class Projectile;
class Health;
class Sprie;

class Knifethrower
{
public: 
	Knifethrower( Point2f SpawnPos );
	void Update( float elapsedSec );
	void Draw();
private:
	Projectile* m_pKnife;
	Health* m_pHealth;
	Point2f m_Position;

	//const Sprite*
};

