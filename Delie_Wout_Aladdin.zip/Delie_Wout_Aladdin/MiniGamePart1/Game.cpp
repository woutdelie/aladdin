#include "pch.h"
#include <iostream>
#include "Game.h"
#include "utils.h"
#include "Camera.h"
#include "Hud.h"
#include "TextureManager.h"
#include "SoundManager.h"
#include "Stickman.h"
#include <fstream>
#include <sstream>
#include "Enemy.h"

Game::Game( const Window& window )
	:BaseGame{ window }

	,m_EndReached{false}
	//,m_Zoom{1.f}
{	 
	Initialize( );
}

Game::~Game() {
	Cleanup( );
}

void Game::Initialize()
{
	m_pTextureManager= new TextureManager{} ;
	m_pSoundManager = new SoundManager{};
	m_pAvatar = new Avatar(m_pTextureManager,m_pSoundManager);
	m_pPowerUpManager = new PowerUpManager();
	AddPowerUps("PowerUps.txt");
	m_pLevel = new Level();
	m_pCamera = new Camera( GetViewPort().width / 2, GetViewPort().height / 2 );
	m_pCamera->SetLevelBoundaries( m_pLevel->GetBoundaries() );
	m_pHud = new Hud( Point2f{ m_pLevel->GetBoundaries().left,m_pLevel->GetBoundaries().bottom + 50.f }, m_pPowerUpManager->Size(),m_pAvatar,m_pTextureManager );
	m_pStickmen.push_back( new Stickman{ Point2f{ 700.0f,57.f }, m_pAvatar, m_pTextureManager,m_pCamera } );
	m_pStickmen.push_back( new Stickman{ Point2f{ 1000.0f,57.f }, m_pAvatar, m_pTextureManager,m_pCamera } );
	m_pStickmen.push_back( new Stickman{ Point2f{ 1700.0f,20.f }, m_pAvatar, m_pTextureManager,m_pCamera } );
	m_pStickmen.push_back( new Stickman{ Point2f{ 1850.0f,250.f }, m_pAvatar, m_pTextureManager,m_pCamera } );
	m_pStickmen.push_back( new Stickman{ Point2f{ 1950.0f,415.f }, m_pAvatar, m_pTextureManager,m_pCamera } );
	
	m_pLevel->PlaySound();
}

void Game::Cleanup( )
{
	delete m_pCamera;
	delete m_pAvatar;
	delete m_pPowerUpManager;
	delete m_pHud;
	delete m_pLevel;
	
	delete m_pTextureManager;
	delete m_pSoundManager;
	for (size_t index{}; index < m_pStickmen.size(); ++index)
	{
		delete m_pStickmen[index];
	}

}

void Game::Update( float elapsedSec )
{
	// Update game objects
	m_EndReached = m_pLevel->HasReachedEnd( m_pAvatar->GetShape() );
	if (!m_EndReached)
	{
		m_pAvatar->Update( elapsedSec, m_pLevel );
		m_pPowerUpManager->Update( elapsedSec );
		m_pHud->SetTopLeft( Point2f{ m_pLevel->GetBoundaries().left + 50.f, m_pLevel->GetBoundaries().bottom + 50.f } );
		m_pHud->Update( elapsedSec );
		for (size_t index{}; index < m_pStickmen.size(); ++index)
		{
			m_pStickmen[index]->Update(elapsedSec);
		}
	}
	
	// Do collision
	DoCollisionTests();
}

void Game::Draw() const
{
	ClearBackground();
	glPushMatrix();
	{
		glScalef( 2.3f, 2.3f, 1.f );
		//centers the player in the middle of the camera
		m_pCamera->Transform( m_pAvatar->GetShape() );
		//draw the background
		m_pLevel->DrawBackground();
		//draw the powerups
		m_pPowerUpManager->Draw();

		m_pAvatar->Draw();
		for (size_t index{}; index < m_pStickmen.size(); ++index)
		{
			m_pStickmen[index]->Draw();
		}
		//m_pStickMan->Draw();
		m_pLevel->DrawForeground();
	}
	glPopMatrix();

	glPushMatrix();
	{
		m_pHud->Draw();
	}
	glPopMatrix();

	if (m_EndReached == true)
	{
		utils::SetColor( Color4f{ 0.0f,0.0f,0.f,0.5f } );
		utils::FillRect( Rectf{ 0,0,GetViewPort().width,GetViewPort().height } );
	}
}

void Game::ProcessKeyDownEvent( const SDL_KeyboardEvent& e )
{
	switch (e.keysym.sym)
	{
	case SDLK_i:
		ShowTestMessage();
		break;
	case SDLK_p:
		break;
	}
	m_pLevel->ProcessKeyDownEvent( e );

}

void Game::ProcessKeyUpEvent( const SDL_KeyboardEvent& e )
{
}

void Game::ProcessMouseMotionEvent( const SDL_MouseMotionEvent& e )
{
}

void Game::ProcessMouseDownEvent( const SDL_MouseButtonEvent& e )
{
}

void Game::ProcessMouseUpEvent( const SDL_MouseButtonEvent& e )
{
}

void Game::ClearBackground( ) const
{
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
	glClear( GL_COLOR_BUFFER_BIT );
}


void Game::ShowTestMessage( ) const
{
	std::cout << "RIGHT arrow key is running to the right\n";
	std::cout << "LEFT arrow key is run to the left\n";
	std::cout << "UP arrow key is look up/ go up ropes\n";
	std::cout << "DOWN arrow key is to crouch/ go down ropes\n";
	std::cout << "S key is to throw an apple\n";
	std::cout << "SPACE key is to jump\n";
	std::cout << "X key is to slash\n";
	std::cout << "Q/A key is to raise/lower volume\n";
	std::cout << "P key is to pause background Music\n";
	std::cout << "R key is to resume background Music\n";

	std::cout << "Keys can be combined to do certain actions down/up/left/right and SPACE with S/X \n";
}

void Game::AddPowerUps( const std::string& filename )const
{
	std::ifstream PowerUpFile{filename};
	if (!PowerUpFile)
	{
		std::cout << "is not open";
		return;
	}
	std::string line;
	while (std::getline( PowerUpFile, line ))
	{
		std::istringstream inputStream{ line };
		float posX, posY;
		int powerUpType;

		if (inputStream >> posX >> posY >> powerUpType)
		{
			Point2f pos{ posX,posY };
			PowerUp::Type type = static_cast<PowerUp::Type>(powerUpType);
			m_pPowerUpManager->AddItem( pos, type );
		}
	}
	PowerUpFile.close();
}

void Game::DoCollisionTests()const
{
	if ( m_pPowerUpManager->HitItem( m_pAvatar->GetShape() ))
	{
		m_pAvatar->PowerUpHit();
		//if(m_pPowerUpManager.==)
		m_pHud->PowerUpHit();
	}
}

