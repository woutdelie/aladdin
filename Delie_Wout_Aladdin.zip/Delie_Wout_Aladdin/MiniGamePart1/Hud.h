#pragma once

class Texture;
class Avatar;
class TextureManager;
class Sprite;

class Hud
{
public:
	Hud(const Point2f& topLeft, int totalPowerUps, Avatar* pAvatar,TextureManager* textureManager );
	Hud(const Hud& other) = delete;
	Hud& operator=(const Hud& other)=delete;
	Hud(Hud&& other) = delete;
	Hud& operator=(Hud&& rhs) = delete;
	~Hud();

	void Draw()const;
	void Update(float elapsedSec);
	void PowerUpHit();
	void SetTopLeft( const Point2f& newPos );
private:
	Point2f m_BottomLeft;
	//const int m_TotalPowerUps;
	int m_HitPowerUps;

	Avatar* m_pAvatar;

	const Texture* m_pLives;
	const Texture* m_pApples;
	const Texture* m_pNumbers;

	Sprite* m_pHealth8;
};

