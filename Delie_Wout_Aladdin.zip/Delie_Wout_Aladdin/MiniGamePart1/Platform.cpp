#include "pch.h"
#include "Platform.h"
#include <Texture.h>
#include <utils.h>

Platform::Platform( const Point2f& bottomLeft )
	:m_BottomLeft{ bottomLeft }

{
	m_pTexture = new Texture( "Images/block.png" );
	m_Shape = Rectf{ bottomLeft.x,bottomLeft.y,m_pTexture->GetWidth(),m_pTexture->GetHeight() };
	m_PlatfromVerts.push_back( Point2f{ m_Shape.left,m_Shape.left } );
	m_PlatfromVerts.push_back( Point2f{ m_Shape.left,m_Shape.bottom + m_Shape.height } );
	m_PlatfromVerts.push_back( Point2f{ m_Shape.left + m_Shape.width,m_Shape.bottom + m_Shape.height } );
	m_PlatfromVerts.push_back( Point2f{ m_Shape.left + m_Shape.width,m_Shape.bottom } );
}

Platform::~Platform()
{
	delete m_pTexture;
}

void Platform::Draw()const
{
	m_pTexture->Draw( Rectf{ m_Shape.left,m_Shape.bottom,0,0 } );
}

void Platform::HandleCollision( Rectf& actorShape, Vector2f& actorVelocity )
{
	Point2f middleBottomCharacter{ actorShape.left + actorShape.width / 2, actorShape.bottom };
	Point2f middleHeightCharacter{ actorShape.left + actorShape.width / 2,actorShape.bottom + actorShape.height };
	utils::HitInfo hitInfo{};
	if (actorVelocity.y < 0 && utils::Raycast( m_PlatfromVerts, middleBottomCharacter, middleHeightCharacter, hitInfo ))
	{
		m_Shape.bottom -= 10.f;
		actorVelocity.y = 0.f;
		actorShape.bottom = hitInfo.intersectPoint.y;
		//for (size_t index{}; index < m_PlatfromVerts.size(); ++index)
		//{
		//	m_PlatfromVerts[index].y -= 10.f;
		//}
	}


}

bool Platform::IsOnGround( const Rectf& actorShape, const Vector2f& actorVelocity )
{
	Point2f middleBottomCharacter{ actorShape.left + actorShape.width / 2, actorShape.bottom - 1 };
	Point2f middleHeightCharacter{ actorShape.left + actorShape.width / 2,actorShape.bottom + actorShape.height };
	utils::HitInfo hitInfo{};

	if (utils::Raycast( m_PlatfromVerts, middleBottomCharacter, middleHeightCharacter, hitInfo ))
	{
		
		return true;
	}
	m_Shape.bottom = m_BottomLeft.y;
	return false;
}
