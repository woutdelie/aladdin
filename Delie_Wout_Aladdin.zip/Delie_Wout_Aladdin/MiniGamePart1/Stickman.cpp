#include "pch.h"
#include "Stickman.h"
#include "Avatar.h"
#include "Sprite.h"
#include <iostream>
#include <utils.h>

Stickman::Stickman( Point2f startPos, Avatar* avatar, TextureManager* textureManager, Camera* camera )
	: Enemy{/*startPos,*/Rectf{startPos.x,startPos.y,40,55}, avatar, camera }

{
	m_pWalkingSprite = new Sprite( "Images/stickmanWalk.png", 9, 9, textureManager );
	m_pHurtSprite = new Sprite( "Images/stickmanHurt.png", 6, 5, textureManager,false );
	m_pSlashSprite = new Sprite( "Images/stickmanSlash.png", 6, 7, textureManager );

}

Stickman::~Stickman()
{
	delete m_pWalkingSprite;
	delete m_pHurtSprite;
	delete m_pSlashSprite;
}

void Stickman::Update( float elapsedSec )
{
	//get update of the base class
	Enemy::Update( elapsedSec );

	//update animation frames
	m_pHurtSprite->Update( elapsedSec );
	m_pWalkingSprite->Update( elapsedSec );
	m_pSlashSprite->Update( elapsedSec );	
}

void Stickman::Draw()const
{
	switch (m_ActionState)
	{
	case Enemy::ActionState::walking:
		m_pWalkingSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Enemy::ActionState::slash:
		m_pSlashSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Enemy::ActionState::hurt:
		m_pHurtSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	}

	if (m_pAvatar->GetShape().left+m_pAvatar->GetShape().width/2.f < Enemy::m_Shape.left+Enemy::m_Shape.width/2.f)
	{
		m_pWalkingSprite->SetDirection( 1 );
		//utils::DrawRect( m_Shape );
		//utils::DrawRect( m_HitTriggerShape );

	}
	else if(m_pAvatar->GetShape().left + m_pAvatar->GetShape().width / 2.f > Enemy::m_Shape.left + Enemy::m_Shape.width / 2.f)
	{
		m_pWalkingSprite->SetDirection( -1 );
		//utils::DrawRect( m_Shape );
		//utils::DrawRect( m_HitTriggerShape );

	}
}
