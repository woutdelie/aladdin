#include "pch.h"
#include "Enemy.h"
#include "Avatar.h"
#include "Health.h"
#include <utils.h>
#include "Camera.h"
#include <iostream>
#include "Projectile.h"

Enemy::Enemy( Rectf shape, Avatar* pavatar, Camera* camera )
	:m_Position{shape.left,shape.bottom}
	,m_Shape{shape}
	,m_HitTriggerShape{shape.left+30.f,shape.bottom,shape.width+60.f,shape.height}
	,m_IsActive{false}
	,m_pAvatar{pavatar}
	,m_ActionState{ActionState::idle}
{
	m_pHealth = new Health{ 2 };
	m_pCamera = camera;
	m_pAladdinProjectile = m_pAvatar->GetProjectile();

}

Enemy::~Enemy()
{
	delete m_pHealth;
}

void Enemy::Update( float elapsedSec )
{
	// when camera is overlapping with an enemy, start moving
	if (utils::IsOverlapping( m_pCamera->GetCameraShape(), m_Shape ))
	{
		m_IsActive = true;
	}
	//reset the enemy when he is outside the camera
	else
	{
		m_Shape.left = m_Position.x;
		m_IsActive = false;
	}
		
	if (!m_IsActive)
		return;

	//check if the enemy has been hurt by aladdin
	CheckAladdinCollision();
	
	//depending if the enemy has healthpoints left start moving and chnage states
	if (m_pHealth->GetHealthPoints() > 0)
	{
		m_HitTriggerShape.left = m_Shape.left - 30.f;
		if ((m_pAvatar->GetShape().left + m_pAvatar->GetShape().width / 2.f < Enemy::m_Shape.left + Enemy::m_Shape.width / 2.f)&&
			(m_pAvatar->GetShape().left + m_pAvatar->GetShape().width < Enemy::m_HitTriggerShape.left))
		{
			m_ActionState = ActionState::walking;
			m_Shape.left -= 40.f * elapsedSec;
			
		}
		else if(m_pAvatar->GetShape().left + m_pAvatar->GetShape().width / 2.f > Enemy::m_Shape.left + Enemy::m_Shape.width / 2.f)
		{
			m_ActionState = ActionState::walking;
			m_Shape.left += 40.f * elapsedSec;
		}
		else if ((m_pAvatar->GetShape().left + m_pAvatar->GetShape().width > Enemy::m_HitTriggerShape.left) &&
				(m_pAvatar->GetShape().left + m_pAvatar->GetShape().width > Enemy::m_Shape.left))
		{
			m_ActionState = ActionState::slash;

		}
		else if ((m_pAvatar->GetShape().left + m_pAvatar->GetShape().width > Enemy::m_HitTriggerShape.left + Enemy::m_HitTriggerShape.width) &&
				(m_pAvatar->GetShape().left + m_pAvatar->GetShape().width > Enemy::m_Shape.left + Enemy::m_Shape.width))
		{
			m_ActionState = ActionState::slash;
		}
	}
	
}

void Enemy::CheckAladdinCollision()
{
	if ((m_pAvatar->GetSlashState() && utils::IsOverlapping( m_pAvatar->GetSwordShape(), m_Shape )) )
	{
		std::cout << "hurt\n";
		m_pHealth->TakeDamage();
		m_ActionState = ActionState::hurt;
	}

	if (m_pAladdinProjectile->GetActive())
	{
		if (utils::IsOverlapping( m_pAladdinProjectile->GetProjectileShape(), m_Shape ))
		{
			std::cout << "appleHurt\n";
			m_pHealth->TakeDamage();
			m_ActionState = ActionState::hurt;
			m_pAladdinProjectile->SetActive( false );
		}
	}
}


