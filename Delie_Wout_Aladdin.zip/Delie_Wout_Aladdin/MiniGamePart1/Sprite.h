#pragma once

class Texture;
class TextureManager;

class Sprite final
{
public:
	Sprite(const std::string& filePath, int nrOfFrames, int nrFramesPerSecond, TextureManager* textureManager ,bool isLooping = true ) ;
	//~Sprite()=default;
	//Sprite(const Sprite& other) = delete;
	//Sprite& operator=(const Sprite& other)=delete;
	//Sprite(Sprite&& other) = delete;
	//Sprite& operator=(Sprite&& rhs) = delete;

	
	void Update(float elapsedSec);
	void Draw(const Rectf& shape)const;
	void Draw(const Point2f& pos)const;

	void ResetAnimation();
	void SetDirection(const int& direction);


	const Texture* GetTexture() const;
	int GetNrOfFrames()const;
	

private:
	const Texture* m_pSpriteTexture;
	float m_ClipHeight;
	float m_ClipWidth;
	const int m_NrOfFrames;
	const int m_NrFramesPerSec;
	float m_AnimTime;
	int m_AnimFrame;
	int m_CurrFrame;

	int m_Direction;
	bool m_IsFinished;
	bool m_IsLooping;

};

