#include "pch.h"
#include "Health.h"

Health::Health( int healthPoints )
	:m_HealthPoints{healthPoints}
{
}

//bool Health::DealDamage( bool IsHit )const
//{
//	if (IsHit)
//		return true;
//	else
//		return false;
//}

void Health::TakeDamage()
{
	--m_HealthPoints;
}

int Health::GetHealthPoints() const
{
	return m_HealthPoints;
}
