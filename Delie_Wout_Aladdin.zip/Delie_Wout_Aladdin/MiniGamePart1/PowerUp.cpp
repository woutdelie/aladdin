#include "pch.h"
#include "PowerUp.h"
#include "Texture.h"
#include "utils.h"


PowerUp::PowerUp( const Point2f& center, PowerUp::Type type )
	:m_Type{ type }
	, m_RotSpeed{ 360 }
	, m_Angle{}
	, m_pAppleTexture{ new Texture( "Images/hudApple.png" ) }
	, m_pGenieBottleTexture{ new Texture( "Images/genieBottle.png" ) }
	, m_pGenieTexture{ new Texture( "Images/genie.png" ) }


{
	m_TextClip = Rectf{ 0.0f,m_pAppleTexture->GetHeight(),m_pAppleTexture->GetWidth(),m_pAppleTexture->GetHeight() };
	m_Shape = Circlef{ center, m_pAppleTexture->GetWidth() };

}

PowerUp::~PowerUp()
{
	//m_pAppleTexture->~Texture();
	delete m_pAppleTexture;
	delete m_pGenieBottleTexture;
	delete m_pGenieTexture;
	m_pAppleTexture = nullptr;

}

void PowerUp::Update( float elapsedSec )
{
	m_Angle += m_RotSpeed * elapsedSec;
}

void PowerUp::Draw() const
{
	glPushMatrix();
	if (m_Type == Type::apple)
	{

		glTranslatef( m_Shape.center.x, m_Shape.center.y, 0.0f );
		//glRotatef(m_Angle, 0, 0, 1);
		glScalef( 0.5f, 0.5f, 1.f );
		glTranslatef( -m_Shape.radius, -m_Shape.radius, 0.0f );
		m_pAppleTexture->Draw( Rectf{}, m_TextClip );
		
		
	}
	//else if (m_Type == Type::fenieBottle)
	//{
	//	m_pGenieBottleTexture->Draw( Rectf{}, Rectf{ 0,m_pGenieBottleTexture->GetHeight(),m_pGenieBottleTexture->GetWidth(),m_pGenieBottleTexture->GetHeight() } );
	//}
	//else if (m_Type == Type::genieBonus)
	//{
	//	m_pGenieTexture->Draw( Rectf{}, Rectf{ 0,m_pGenieTexture->GetHeight(),m_pGenieTexture->GetWidth(),m_pGenieTexture->GetHeight() } );
	//}
	glPopMatrix();
	//else 
	//{
	//	glTranslatef(m_Shape.center.x, m_Shape.center.y , 0.0f);
	//	//glRotatef(m_Angle, 0, 0, 1);
	//	glTranslatef(-m_Shape.radius, -m_Shape.radius, 0.0f);
	//	m_pAppleTexture->Draw(Rectf{}, Rectf{ m_TextClip.left,m_TextClip.height,m_TextClip.width,m_TextClip.bottom - m_TextClip.height });
	//}
}

bool PowerUp::IsOverlapping( const Rectf& rect ) const
{
	if (utils::IsOverlapping( rect, m_Shape ))
	{
		return true;

	}
	else
	{
		return false;
	}

}

PowerUp::Type PowerUp::GetType() const
{
	return m_Type;
}
