#include "pch.h"
#include "Level.h"
#include <Texture.h>
#include <utils.h>
#include <SVGParser.h>
#include <iostream>
#include <vector> 
#include "Platform.h"
#include <SoundStream.h>

Level::Level()
	: m_pBackgroundTexture{ new Texture( "Images/background.png" ) }
	, m_pForegroundTexture{ new Texture( "Images/foreground.png" ) }
	//,m_EndSignShape{Rectf{720,224,0,0}}
{
	m_Boundaries = Rectf{ 0,0,m_pBackgroundTexture->GetWidth(),m_pBackgroundTexture->GetHeight() };

	//platforms
	m_pPlatforms.push_back( new Platform{ Point2f{1624,238} } );
	m_pPlatforms.push_back( new Platform{ Point2f{4199,232} } );
	m_pPlatforms.push_back( new Platform{ Point2f{4102,216} } );

	//level
	std::vector<std::vector<Point2f>> svgBackground;
	std::vector<std::vector<Point2f>> svgMiddleBottomPlatform;
	std::vector<std::vector<Point2f>> svgLeftPlatform;
	std::vector<std::vector<Point2f>> svgMiddleTopPlatform;
	std::vector<std::vector<Point2f>> svgRightLeftPlatform;
	std::vector<std::vector<Point2f>> svgRightRightPlatform;

	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/hitregion_background.svg", svgBackground ))
	{
		m_Vertices.push_back( svgBackground[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/middleBottomPlatform.svg", svgMiddleBottomPlatform ))
	{
		m_Vertices.push_back( svgMiddleBottomPlatform[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/leftPlatform.svg", svgLeftPlatform ))
	{
		m_Vertices.push_back( svgLeftPlatform[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/middleTopPlatform.svg", svgMiddleTopPlatform ))
	{
		m_Vertices.push_back( svgMiddleTopPlatform[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/rightLeftPlatform.svg", svgRightLeftPlatform ))
	{
		m_Vertices.push_back( svgRightLeftPlatform[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/rightRightPlatform.svg", svgRightRightPlatform ))
	{
		m_Vertices.push_back( svgRightRightPlatform[0] );
	}


	//ropes
	std::vector<std::vector<Point2f>> leftBottomRope;
	std::vector<std::vector<Point2f>> leftUpRope;
	std::vector<std::vector<Point2f>> centerRope;
	std::vector<std::vector<Point2f>> rightRope;
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/leftBottomRope.svg", leftBottomRope ))
	{
		m_RopeVertices.push_back( leftBottomRope[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/leftUpRope.svg", leftUpRope ))
	{
		m_RopeVertices.push_back( leftUpRope[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/centerRope.svg", centerRope ))
	{
		m_RopeVertices.push_back( centerRope[0] );
	}
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/rightRope.svg", rightRope ))
	{
		m_RopeVertices.push_back( rightRope[0] );
	}

	//fire
	SVGParser::GetVerticesFromSvgFile( "Images/svg/fire.svg", m_FireVertices );

	//stairs

	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/frontStairs.svg", m_FrontStairsVertices ));
	if (SVGParser::GetVerticesFromSvgFile( "Images/svg/backStairs.svg", m_BackStairsVertices ));
	
	//beams
	std::vector<std::vector<Point2f>> beamBottom;
	std::vector<std::vector<Point2f>> beamUp;
	SVGParser::GetVerticesFromSvgFile("Images/svg/beamBottom.svg", beamBottom);
	{
		m_BeamVertices.push_back( beamBottom[0] );
	}
	SVGParser::GetVerticesFromSvgFile( "Images/svg/beamUp.svg", beamUp );
	{
		m_BeamVertices.push_back( beamUp[0] );
	}

	//sound
	m_pBackgroundMusic = new SoundStream{ "Sounds/Prince Ali.MP3" };

	//m_pEndSignTexture = new Texture("Images/EndSign.png");
}

Level::~Level()
{
	delete m_pBackgroundTexture;
	delete m_pForegroundTexture;
	for (size_t index{}; index < m_pPlatforms.size(); index++)
	{
		delete m_pPlatforms[index];
	}
	delete m_pBackgroundMusic;
	//delete m_pEndSignTexture;
}

void Level::DrawBackground()const
{
	m_pBackgroundTexture->Draw();

	for (size_t index{}; index < m_pPlatforms.size(); index++)
	{
		m_pPlatforms[index]->Draw();
	}
	
}

void Level::DrawForeground() const
{
	//for (int index{ 0 }; index < m_Vertices.size(); ++index)
	//{
	//	utils::DrawPolygon( m_Vertices[index] );
	//}
	m_pForegroundTexture->Draw();
	//for (int index{ 0 }; index < m_BeamVertices.size(); ++index)
	//{
	//	utils::DrawPolygon( m_BeamVertices[index], true, 1.f );
	//}
	//for (int index{ 0 }; index < m_RopeVertices.size(); ++index)
	//{
	//	utils::SetColor( Color4f{ 1.f,0.f,0.f,1.f } );
	//	utils::DrawPolygon( m_RopeVertices[index], true, 1.f );
	//}

	//m_pEndSignTexture->Draw(m_EndSignShape, Rectf{0,0,0,0});
}

void Level::HandleCollision(Rectf& actorShape, Vector2f& actorVelocity)const
{
	
	Point2f middleBottomCharacter{ actorShape.left + actorShape.width / 2, actorShape.bottom };
	Point2f middleHeightCharacter{ actorShape.left + actorShape.width / 2,actorShape.bottom + actorShape.height/2.f };

	utils::HitInfo hitInfo{};
	for (int index{ 0 }; index < m_Vertices.size(); ++index)
	{
		if (utils::Raycast(m_Vertices[index], middleBottomCharacter, middleHeightCharacter, hitInfo))
		{
			if (hitInfo.lambda < 0.5f)
			{
				actorShape.bottom = hitInfo.intersectPoint.y;
				actorVelocity.y = 0;
			}
		}

		else
		{
			for (size_t index{}; index < m_pPlatforms.size(); index++)
			{
				m_pPlatforms[index]->HandleCollision(actorShape, actorVelocity);
			}
			
		}
	}

	for (int index{ 0 }; index < m_FrontStairsVertices.size(); ++index)
	{
		if (utils::Raycast(m_FrontStairsVertices[index], middleBottomCharacter, middleHeightCharacter, hitInfo))
		{
			if (hitInfo.lambda < 0.5f)
			{
				actorShape.bottom = hitInfo.intersectPoint.y;
						actorVelocity.y = 0;
			}
		}
	}
	for (int index{ 0 }; index < m_BackStairsVertices.size(); ++index)
	{
		if (utils::Raycast( m_BackStairsVertices[index], middleBottomCharacter, middleHeightCharacter, hitInfo ))
		{
			if (hitInfo.lambda < 0.5f)
			{
				actorShape.bottom = hitInfo.intersectPoint.y;
				actorVelocity.y = 0;
			}
		}
	}


}

bool Level::IsOnGround( const Rectf& actorShape, Vector2f& actorVelocity )const
{

	Point2f middleBottomCharacter{ actorShape.left + actorShape.width / 2, actorShape.bottom - 1 };
	Point2f middleHeightCharacter{ actorShape.left + actorShape.width / 2,actorShape.bottom + actorShape.height };
	utils::HitInfo hitInfo{};

	for (int index{ 0 }; index < m_Vertices.size(); ++index)
	{
		if (utils::Raycast( m_Vertices[index], middleBottomCharacter, middleHeightCharacter, hitInfo ))
		{
			return true;
		}

	}
	for (int index{ 0 }; index < m_FrontStairsVertices.size(); ++index)
	{
		if (utils::Raycast( m_FrontStairsVertices[index], middleBottomCharacter, middleHeightCharacter, hitInfo ))
		{
			return true;
		}
	}
	for (size_t index{}; index < m_pPlatforms.size(); index++)
	{
		return m_pPlatforms[index]->IsOnGround( actorShape, actorVelocity );
	}
	return false;
}

void Level::HandleWallCollision( Rectf& actorShape, Vector2f& actorVelocity ) const
{
	Point2f bottomLeftCharacter{ actorShape.left , actorShape.bottom + actorShape.height / 2.f };
	Point2f bottomRightCharacter{ actorShape.left + actorShape.width,actorShape.bottom + actorShape.height / 2.f };

	utils::HitInfo hitInfo{};
	for (int index{ 0 }; index < m_Vertices.size(); ++index)
	{
		if (utils::Raycast( m_Vertices[index], bottomLeftCharacter, bottomRightCharacter, hitInfo ))
		{
			if (hitInfo.intersectPoint.x < actorShape.left + actorShape.width / 2)
			{
				actorShape.left = hitInfo.intersectPoint.x;
			}
			else if (hitInfo.intersectPoint.x > actorShape.left + actorShape.width / 2)
			{
				actorShape.left = hitInfo.intersectPoint.x - actorShape.width;
			}
			actorVelocity.x = 0;
		}
	}
}
void Level::HandleHeadCollision( Rectf& actorShape ) const
{
	Point2f middleBottomCharacter{ actorShape.left + actorShape.width / 2.f , actorShape.bottom + actorShape.height / 2.f };
	Point2f middleHeightCharacter{ actorShape.left + actorShape.width / 2.f ,actorShape.bottom + actorShape.height };

	utils::HitInfo hitInfo{};
	for (int index{ 0 }; index < m_Vertices.size(); ++index)
	{
		if (utils::Raycast( m_Vertices[index], middleBottomCharacter, middleHeightCharacter, hitInfo ))
		{
			if (hitInfo.lambda > 0.5f)
			{
				actorShape.bottom = hitInfo.intersectPoint.y - actorShape.height;
			}
		}

	}
}
bool Level::HandleRopeCollision( Rectf& actorShape ) const
{
	Point2f bottomCharacter{ actorShape.left , actorShape.bottom };
	Point2f middleHeightCharacter{ actorShape.left + actorShape.width ,actorShape.bottom + actorShape.height };

	utils::HitInfo hitInfo{};
	for (int index{ 0 }; index < m_RopeVertices.size(); ++index)
	{
		if (utils::Raycast( m_RopeVertices[index], bottomCharacter, middleHeightCharacter, hitInfo ))
		{
			/*if (index == 0)
			{
				float heightRopeCenter{ m_RopeVertices[index][5].x - m_RopeVertices[index][0].x };
				heightRopeCenter /= 2.f;
				heightRopeCenter += m_RopeVertices[index][0].x;
				actorShape.left = heightRopeCenter - actorShape.width / 2.f;
				return true;
			}
			else if (index == 1)
			{
				float heightRopeCenter{ m_RopeVertices[index][5].x - m_RopeVertices[index][0].x };
				heightRopeCenter /= 2.f;
				heightRopeCenter += m_RopeVertices[index][0].x;
				actorShape.left = heightRopeCenter - actorShape.width / 2.f;
				return true;
			}
			else if (index == 2)
			{
				float heightRopeCenter{ m_RopeVertices[index][5].x - m_RopeVertices[index][0].x };
				heightRopeCenter /= 2.f;
				heightRopeCenter += m_RopeVertices[index][0].x;
				actorShape.left = heightRopeCenter - actorShape.width / 2.f;
				return true;
			}
			else if (index == 3)
			{*/
				float heightRopeCenter{ m_RopeVertices[index][5].x - m_RopeVertices[index][0].x };
				heightRopeCenter /= 2.f;
				heightRopeCenter += m_RopeVertices[index][0].x;
				
				actorShape.left = heightRopeCenter - actorShape.width / 2.f;
			//actorShape.left = hitInfo.intersectPoint.x - actorShape.width / 2.f;
				return true;
			//}
			//return true;
		}
	}
	return false;
}
bool Level::HandleFireCollision( const Rectf& actorShape ) const
{
	Point2f middleCharacter{ actorShape.left + actorShape.width / 2.f, actorShape.bottom + actorShape.height / 2.f };
	Point2f middleBottomCharacter{ actorShape.left + actorShape.width / 2.f ,actorShape.bottom };
	utils::HitInfo hitInfo{};
	for (int index{ 0 }; index < m_FireVertices.size(); ++index)
	{
		if (utils::Raycast( m_FireVertices[index], middleCharacter, middleBottomCharacter, hitInfo ))
		{
			return true;
		}
	}
	return false;
}
bool Level::HandleBeamCollision( Rectf& actorShape ) const
{
	Point2f middleBottomCharacter{ actorShape.left + actorShape.width / 2.f , actorShape.bottom + actorShape.height/4.f*3.f  };
	Point2f middleHeightCharacter{ actorShape.left + actorShape.width / 2.f ,actorShape.bottom + actorShape.height };
	utils::HitInfo hitInfo{};
	for (int index{ 0 }; index < m_BeamVertices.size(); ++index)
	{
		if (utils::Raycast( m_BeamVertices[index], middleBottomCharacter, middleHeightCharacter, hitInfo ))
		{
			if (hitInfo.lambda > 0.5f)
			{
				actorShape.bottom = hitInfo.intersectPoint.y- actorShape.height/2.f;
				return true;
			}
		}

	}
	return false;
}

Rectf Level::GetBoundaries()const
{
	return m_Boundaries;
}

bool Level::HasReachedEnd( const Rectf& actorShape ) const
{
	//if (actorShape.left + actorShape.width >= m_EndSignShape.left)
	//{
	//	return true;
	//}
	return false;
}

void Level::PlaySound()
{
	m_pBackgroundMusic->SetVolume( 51 );
	m_pBackgroundMusic->Play(true);
}

void Level::ProcessKeyDownEvent( const SDL_KeyboardEvent& e )
{
	switch (e.keysym.sym)
	{
	case SDLK_a:
		m_pBackgroundMusic->SetVolume( m_pBackgroundMusic->GetVolume() - 16 );
		std::cout<<m_pBackgroundMusic->GetVolume()<<std::endl;
		break;
	case SDLK_q:
		m_pBackgroundMusic->SetVolume( m_pBackgroundMusic->GetVolume() + 16 );
		std::cout << m_pBackgroundMusic->GetVolume()<<std::endl;
		break;
	case SDLK_p:
		m_pBackgroundMusic->Pause();
		break;
	case SDLK_r:
		m_pBackgroundMusic->Resume();
		break;
	}

}