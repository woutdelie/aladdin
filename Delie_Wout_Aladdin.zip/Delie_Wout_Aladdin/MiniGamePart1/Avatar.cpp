#include "pch.h"
#include "Avatar.h"
#include <utils.h>
#include "PowerUpManager.h"
#include <Texture.h>
#include <iostream>
#include "Sprite.h"
#include "Projectile.h"
#include "TextureManager.h"
#include <SoundEffect.h>
#include "SoundManager.h"
#include "Health.h"

Avatar::Avatar( TextureManager* textureManager, SoundManager* soundManager )
	: m_HorSpeed{ 150.0f }
	, m_SmallJumpSpeed{ 300.0f }
	, m_HighJumpSpeed{ 400.f }
	, m_Velocity{ Vector2f{0,0} }
	, m_Acceleration{ Vector2f{0,-981.0f} }
	, m_ActionState{ ActionsState::running }
	//, m_AccuTransformSec{ 0.0f }
	//, m_MaxTransformSec{ 1.0f }
	, m_Direction{ 1 }
	, m_AppleAmount{ 10 }
	, m_AppleHit{ false }
	, m_AppleVelocity{}
	, m_JumpTimer{}
	,m_IsPressedOnce{false}

{
	//m_pFire = new Texture( "Images/fire.png" );

	//sounds
	m_pHighSlash = soundManager->GetSoundEffect("Sounds/High Sword.WAV");

	m_StartPos = Point2f{ 80,50 };
	m_Shape = Rectf{ m_StartPos.x, m_StartPos.y, 0, 0 };

	m_SwordShape = Rectf{ m_Shape.left + m_Shape.width / 2.f,m_Shape.bottom + m_Shape.height / 2.f, m_Shape.width / 2.f,20 };
	// m_actionstate = state -> changeState(state)
	m_pIdleSprite = new Sprite( "Images/idleLeftRight.png", 7, 7, textureManager );
	m_pRunningSprite = new Sprite( "Images/running.png", 12, 13, textureManager );
	m_pRunningJumpSprite = new Sprite( "Images/runningJump.png", 9, 7, textureManager);
	m_pLookUpSprite = new Sprite( "Images/LookUp.png", 3, 5, textureManager, false );
	m_pAppleThrowSprite = new Sprite( "Images/applethrowNormal.png", 6, 9, textureManager, false );
	m_pCrouchSprite = new Sprite( "Images/crouch.png", 4, 6, textureManager, false );
	m_pSlashSprite = new Sprite( "Images/slashNormal.png", 5, 11,textureManager );
	m_pClimbingSprite = new Sprite( "Images/climbing.png", 10, 13 ,textureManager );
	m_pMonkeyBarsMovingSprite = new Sprite( "Images/monkeybarsMoving.png", 10, 10,textureManager );
	m_pAppleCrouch = new Sprite( "Images/appleCrouch.png", 5, 7,textureManager );
	m_pAladdinHurt = new Sprite( "Images/hurt.png", 6, 7,textureManager );
	m_pJumpingAppleSprite = new Sprite( "Images/jumpingApple.png", 5, 7,textureManager );
	m_pJumpingSlashSprite = new Sprite( "Images/jumpingSlash.png", 6, 9,textureManager );
	m_pMonkeyBarsIdleSprite = new Sprite( "Images/monkeybarsIdle.png", 5, 7,textureManager );
	m_pMonkeyBarsAppleSprite = new Sprite( "Images/monkeybarsApple.png", 5, 7,textureManager );
	m_pMonkeyBarsSlashSprite = new Sprite( "Images/monkeybarsSlash.png", 7, 8,textureManager );
	m_pRopeJumpSprite = new Sprite( "Images/ropeJump.png", 9, 10,textureManager );
	m_pRunningStopSprite = new Sprite( "Images/runningStop.png", 9, 10,textureManager );
	m_pSlashCrouchSprite = new Sprite( "Images/slashCrouch.png", 7, 8,textureManager );
	m_pLandingSprite = new Sprite( "Images/landing.png", 6, 7,textureManager );
	m_pNormalJumpSprite = new Sprite( "Images/normalJump.png", 10, 12,textureManager );
	m_pGreatLanding = new Sprite( "Images/greatLanding.png", 10, 12,textureManager );

	m_pHealth = new Health{ 8 };

	m_ApplePos = Point2f{ };
	m_pApple = new Projectile( "Images/apple.png", m_ApplePos );
}
Avatar::~Avatar()
{
	delete m_pApple;
	delete m_pHealth;

	delete m_pIdleSprite;
	delete m_pRunningSprite;
	delete m_pRunningJumpSprite;
	delete m_pLookUpSprite;
	delete m_pAppleThrowSprite;
	delete m_pCrouchSprite;
	delete m_pSlashSprite;
	delete m_pClimbingSprite;
	delete m_pMonkeyBarsMovingSprite;
	delete m_pAppleCrouch;
	delete m_pAladdinHurt;
	delete m_pJumpingAppleSprite;
	delete m_pJumpingSlashSprite;
	delete m_pMonkeyBarsIdleSprite;
	delete m_pMonkeyBarsAppleSprite;
	delete m_pMonkeyBarsSlashSprite;
	delete m_pRopeJumpSprite;
	delete m_pRunningStopSprite;
	delete m_pSlashCrouchSprite;
	delete m_pNormalJumpSprite;
	delete m_pLandingSprite;
	delete m_pGreatLanding;
}

void Avatar::Update( float elapsedSec, const Level* level )
{
	const Uint8* pStates = SDL_GetKeyboardState( nullptr );
	
	//checks if the avatar is on the ground and if true allow to jump again
	if (m_pHealth->GetHealthPoints()>0)
	{
		JumpInput( elapsedSec, level );

		InputActions( elapsedSec, level );

		if (m_ActionState == ActionsState::climbing ||
			m_ActionState == ActionsState::monkeybarsIdle ||
			m_ActionState == ActionsState::monkeybarsMoving ||
			m_ActionState == ActionsState::monkeybarApple ||
			m_ActionState == ActionsState::monkeybarsSlash)
		{
			m_Acceleration.y = 0;
		}
		else
		{
			m_Acceleration.y = -981.f;
		}

		UpdateApple( elapsedSec, level );

		m_Velocity.y += m_Acceleration.y * elapsedSec;
		m_Shape.left += m_Velocity.x * elapsedSec;
		m_Shape.bottom += m_Velocity.y * elapsedSec;

		GetSwordShape();
		UpdateSwordPosition();
	}

	level->HandleCollision( m_Shape, m_Velocity );
	level->HandleWallCollision( m_Shape, m_Velocity );
	level->HandleHeadCollision( m_Shape );
}

void Avatar::Draw()const
{
	//utils::DrawRect( m_Shape );
	//utils::DrawRect( m_SwordShape );
	//Rectf srcRect{ m_ClipWidth * m_AnimFrame,m_ClipHeight,m_ClipWidth,m_ClipHeight };
	//utils::DrawRect( srcRect );

	switch (m_ActionState)
	{
	case Avatar::ActionsState::idle:
		m_pIdleSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::running:
		m_pRunningSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::hurt:
		m_pAladdinHurt->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::slash:
		m_pSlashSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::crouch:
		m_pCrouchSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::runningStop:
		m_pRunningStopSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::appleThrow:
		m_pAppleThrowSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::normalJump:
		m_pNormalJumpSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::runningJump:
		m_pRunningJumpSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::jumpingApple:
		m_pJumpingAppleSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::jumpingSlash:
		m_pJumpingSlashSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::landing:
		m_pLandingSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::greatLanding:
		m_pGreatLanding->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::climbing:
		m_pClimbingSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::lookUp:
		m_pLookUpSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::appleCrouch:
		m_pAppleCrouch->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::slashCrouch:
		m_pSlashCrouchSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::monkeybarsMoving:
		m_pMonkeyBarsMovingSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::monkeybarsIdle:
		m_pMonkeyBarsIdleSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::monkeybarApple:
		m_pMonkeyBarsAppleSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::monkeybarsSlash:
		m_pMonkeyBarsSlashSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	case Avatar::ActionsState::ropeJump:
		m_pRopeJumpSprite->Draw( Point2f{ m_Shape.left,m_Shape.bottom } );
		break;
	}

	if (m_AppleAmount> 0)
	{
		if (m_pApple->GetActive())
		{
			if (m_AppleHit)
			{
				return;
			}
			m_pApple->Draw();
		}
	}

}

void Avatar::PowerUpHit()
{
	++m_AppleAmount;
}

int Avatar::GetAppleAmount() const
{
	return m_AppleAmount;
}

//return the shape of the avatar
Rectf Avatar::GetShape()const
{
	return m_Shape;
}

Rectf Avatar::GetAppleShape() const
{
	return Rectf{ m_pApple->GetPostition().x , m_pApple->GetPostition().y , 7 , 7 };
}

Projectile* Avatar::GetProjectile() const
{
	return m_pApple;
}

bool Avatar::GetSlashState() const
{
	if (m_ActionState == ActionsState::slash)
		return true;

	return false;
}

//depending on what key pressed, do the assigned action and set the state
void Avatar::InputActions( float elapsedSec, const Level* pLevel )
{
	//system( "cls" );
	const Uint8* pStates = SDL_GetKeyboardState( nullptr );

	//monkey bars under development

	//idle monkeybars
	if (pLevel->HandleBeamCollision( m_Shape ))
	{
		ChangeState( ActionsState::monkeybarsIdle );
		m_pMonkeyBarsIdleSprite->SetDirection( m_Direction );
		m_Shape.width = m_pMonkeyBarsIdleSprite->GetTexture()->GetWidth() / m_pMonkeyBarsMovingSprite->GetNrOfFrames();
		m_Shape.height = m_pMonkeyBarsIdleSprite->GetTexture()->GetHeight();
		m_pMonkeyBarsIdleSprite->Update( elapsedSec );
		m_Shape.bottom -= 10.f;
		m_Velocity.y = 0;
	}
	//moving left monkeyBars
	else if (pLevel->HandleBeamCollision( m_Shape ) && pStates[SDL_SCANCODE_LEFT])
	{
		ChangeState( ActionsState::monkeybarsMoving );
		m_pMonkeyBarsMovingSprite->SetDirection( m_Direction );
		m_Shape.width = m_pMonkeyBarsMovingSprite->GetTexture()->GetWidth() / m_pMonkeyBarsMovingSprite->GetNrOfFrames();
		m_Shape.height = m_pMonkeyBarsMovingSprite->GetTexture()->GetHeight();
		m_pMonkeyBarsMovingSprite->Update( elapsedSec );
		m_Shape.bottom -= 20.f;
		m_Velocity.y = 0;
	}

	//moving right monkeyBars
	else if (pLevel->HandleBeamCollision( m_Shape ) && pStates[SDL_SCANCODE_RIGHT])
	{
		ChangeState( ActionsState::monkeybarsMoving );
		m_pMonkeyBarsMovingSprite->SetDirection( m_Direction );
		m_Shape.width = m_pMonkeyBarsMovingSprite->GetTexture()->GetWidth() / m_pMonkeyBarsMovingSprite->GetNrOfFrames();
		m_Shape.height = m_pMonkeyBarsMovingSprite->GetTexture()->GetHeight();
		m_pMonkeyBarsMovingSprite->Update( elapsedSec );
		m_Shape.bottom -= 20.f;
		m_Velocity.y = 0;
	}
	
	//end under development

	//set the velocty forwards and runningtexture
	else if (pStates[SDL_SCANCODE_RIGHT] && !pStates[SDL_SCANCODE_SPACE]&& pLevel->HandleBeamCollision(m_Shape)==false)
	{
		m_Velocity.x = m_HorSpeed;
		ChangeState( ActionsState::running );

		if (m_Direction != 1)
		{
			m_pRunningSprite->SetDirection( 1 );
			m_Direction = 1;
			m_pRunningSprite->ResetAnimation();
			
		}
		m_Shape.width = m_pRunningSprite->GetTexture()->GetWidth() / m_pRunningSprite->GetNrOfFrames();
		m_Shape.height = m_pRunningSprite->GetTexture()->GetHeight();
		m_pRunningSprite->Update( elapsedSec );
	}
	//set the velocity backwards and runningtexture
	else if (pStates[SDL_SCANCODE_LEFT] && !pStates[SDL_SCANCODE_SPACE] && pLevel->HandleBeamCollision( m_Shape ) == false)
	{
		m_Velocity.x = -m_HorSpeed;
		ChangeState( ActionsState::running );

		if (m_Direction != -1)
		{
			m_pRunningSprite->SetDirection( -1 );
			m_Direction = -1;
			m_pRunningSprite->ResetAnimation();
			
		}
		m_Shape.width = m_pRunningSprite->GetTexture()->GetWidth() / m_pRunningSprite->GetNrOfFrames();
		m_Shape.height = m_pRunningSprite->GetTexture()->GetHeight();
		m_pRunningSprite->Update( elapsedSec );
	}

	//apple crouch
	else if (pStates[SDL_SCANCODE_DOWN] && pStates[SDL_SCANCODE_S])
	{
		m_Velocity.x = 0;
		ChangeState( ActionsState::appleCrouch );
		m_pAppleCrouch->SetDirection( m_Direction );
		m_Shape.width = m_pAppleCrouch->GetTexture()->GetWidth() / m_pAppleCrouch->GetNrOfFrames();
		m_Shape.height = m_pAppleCrouch->GetTexture()->GetHeight();
		m_pAppleCrouch->Update( elapsedSec );
		
		AppleThrow( m_pAppleCrouch );
	}
	
	//rope climbing up
	else if (pStates[SDL_SCANCODE_UP] && pLevel->HandleRopeCollision( m_Shape ) )
	{
		ChangeState( ActionsState::climbing );

		m_Shape.width = m_pClimbingSprite->GetTexture()->GetWidth() / m_pClimbingSprite->GetNrOfFrames();
		m_Shape.height = m_pClimbingSprite->GetTexture()->GetHeight();
		m_pClimbingSprite->Update( elapsedSec );
		m_Velocity.y = 100;
		//SDL_Log( "Climbing up" );
	}
	//rope climbing down
	else if (pStates[SDL_SCANCODE_DOWN] && pLevel->HandleRopeCollision( m_Shape ) )
	{
		ChangeState( ActionsState::climbing );
		m_Shape.width = m_pClimbingSprite->GetTexture()->GetWidth() / m_pClimbingSprite->GetNrOfFrames();
		m_Shape.height = m_pClimbingSprite->GetTexture()->GetHeight();
		m_pClimbingSprite->Update( elapsedSec );

		m_Velocity.y = -100;
		//SDL_Log( "Climbing down" );
	}

	//idle rope
	else if (pLevel->HandleRopeCollision( m_Shape ) )
	{
		m_Velocity.y = 0;
	}

	//lookuptexturee
	else if (pStates[SDL_SCANCODE_UP] && m_Velocity.x <= 0 && m_Velocity.y >= 0)
	{
		ChangeState( ActionsState::lookUp );
		m_pLookUpSprite->SetDirection( m_Direction );
		m_Shape.width = m_pLookUpSprite->GetTexture()->GetWidth() / m_pLookUpSprite->GetNrOfFrames();
		m_Shape.height = m_pLookUpSprite->GetTexture()->GetHeight();
		m_pLookUpSprite->Update( elapsedSec );
		//SDL_Log( "lookup" );

	}
	// crouch slash
	else if (pStates[SDL_SCANCODE_DOWN] && pStates[SDL_SCANCODE_S] && (m_Velocity.x <= 0 && m_Velocity.y <= 0))
	{
		m_Velocity.x = 0;
		ChangeState( ActionsState::slashCrouch );
		m_pSlashCrouchSprite->SetDirection( m_Direction );
		m_Shape.width = m_pSlashCrouchSprite->GetTexture()->GetWidth() / m_pSlashCrouchSprite->GetNrOfFrames();
		m_Shape.height = m_pSlashCrouchSprite->GetTexture()->GetHeight();
		m_pSlashCrouchSprite->Update( elapsedSec );
	}
	//crouchtexture
	else if (pStates[SDL_SCANCODE_DOWN] && m_Velocity.x <= 0 && m_Velocity.y <= 0)
	{
		m_Velocity.x = 0;
		ChangeState( ActionsState::crouch );
		m_pCrouchSprite->SetDirection( m_Direction );
		m_Shape.width = m_pCrouchSprite->GetTexture()->GetWidth() / m_pCrouchSprite->GetNrOfFrames();
		m_Shape.height = m_pCrouchSprite->GetTexture()->GetHeight();
		m_pCrouchSprite->Update( elapsedSec );

	}
	//applethrowtexture
	else if (pStates[SDL_SCANCODE_S] && m_Velocity.x <= 0&& m_Velocity.x>=0)
	{
		ChangeState( ActionsState::appleThrow );
		m_pAppleThrowSprite->SetDirection( m_Direction );
		m_Shape.width = m_pAppleThrowSprite->GetTexture()->GetWidth() / m_pAppleThrowSprite->GetNrOfFrames();
		m_Shape.height = m_pAppleThrowSprite->GetTexture()->GetHeight();
		m_pAppleThrowSprite->Update( elapsedSec );

		AppleThrow(m_pAppleThrowSprite);
	}

	//normal slash 
	else if (pStates[SDL_SCANCODE_X] && (m_Velocity.x <= 0 && m_Velocity.x >= 0))
	{
		ChangeState( ActionsState::slash );
		m_pSlashSprite->SetDirection( m_Direction );
		m_Shape.width = m_pSlashSprite->GetTexture()->GetWidth() / m_pSlashSprite->GetNrOfFrames();
		m_Shape.height = m_pSlashSprite->GetTexture()->GetHeight();
		m_pSlashSprite->Update( elapsedSec );
		
		if (m_IsPressedOnce == false)
		{
			m_pHighSlash->Play( 0 );
		}
		m_IsPressedOnce == true;

	}
	//jumpingSlash
	else if(pStates[SDL_SCANCODE_X]&& pStates[SDL_SCANCODE_SPACE])
	{
		ChangeState( ActionsState::jumpingSlash );
		m_pJumpingSlashSprite->SetDirection( m_Direction );
		m_Shape.width = m_pJumpingSlashSprite->GetTexture()->GetWidth() / m_pJumpingSlashSprite->GetNrOfFrames();
		m_Shape.height = m_pJumpingSlashSprite->GetTexture()->GetHeight();
		m_pJumpingSlashSprite->Update( elapsedSec );
	}
	//jumpingApple
	else if (pStates[SDL_SCANCODE_S] && pStates[SDL_SCANCODE_SPACE])
	{
		ChangeState( ActionsState::jumpingApple );
		m_pJumpingAppleSprite->SetDirection( m_Direction );
		m_Shape.width = m_pJumpingAppleSprite->GetTexture()->GetWidth() / m_pJumpingAppleSprite->GetNrOfFrames();
		m_Shape.height = m_pJumpingAppleSprite->GetTexture()->GetHeight();
		m_pJumpingAppleSprite->Update( elapsedSec );
		AppleThrow(m_pJumpingAppleSprite);

	}

	//jump while running
	else if (pStates[SDL_SCANCODE_SPACE] && (m_Velocity.x < 0|| m_Velocity.x > 0))
	{
		ChangeState( ActionsState::runningJump );
		m_pRunningJumpSprite->SetDirection( m_Direction);
		m_Shape.width = m_pRunningJumpSprite->GetTexture()->GetWidth() / m_pRunningJumpSprite->GetNrOfFrames();
		//m_Shape.height = m_pRunningJumpSprite->GetTexture()->GetHeight();
		m_pRunningJumpSprite->Update( elapsedSec );
		//SDL_Log( "normal jump" );

	}
	//idle/normal jump
	else if (pStates[SDL_SCANCODE_SPACE] )
	{
		ChangeState( ActionsState::normalJump );
		m_pNormalJumpSprite->SetDirection( m_Direction );
		m_Shape.width = m_pNormalJumpSprite->GetTexture()->GetWidth() / m_pNormalJumpSprite->GetNrOfFrames();
		//m_Shape.height = m_pRunningJumpSprite->GetTexture()->GetHeight();
		m_pNormalJumpSprite->Update( elapsedSec );
	}
	//set the velocity to 0/ set to idle state
	else
	{
		ChangeState( ActionsState::idle );
		m_pIdleSprite->SetDirection( m_Direction );
		m_Shape.width = m_pIdleSprite->GetTexture()->GetWidth() / m_pIdleSprite->GetNrOfFrames();
		m_Shape.height = m_pIdleSprite->GetTexture()->GetHeight();
		m_pIdleSprite->Update( elapsedSec );

		m_Velocity.x = 0;
		m_IsPressedOnce = false;
		//SDL_Log( "Idle" );
	}
}

void Avatar::UpdateApple( float elapsedSec, const Level* level )
{
	//as long as the apple doesnt touch the ground update the apple
	if ( level->IsOnGround ( Rectf{ m_pApple->GetPostition().x , m_pApple->GetPostition().y , 7 , 7 }, m_AppleVelocity ) == false )
	{
		m_pApple->Update( elapsedSec );
		m_AppleHit = false;
	}
	else
	{
		m_pApple->SetActive( false );
	}
}

void Avatar::AppleThrow(const Sprite* sprite )
{
	if (m_AppleAmount > 0)
	{
		//if apple not thrown set the spawnpoint and direction to the right place
		if (m_pApple->GetActive() == false)
		{
			m_pApple->SetDirection( m_Direction );
			if (m_Direction == 1)
			{
				m_pApple->SetSpawnPoint( Point2f{ m_Shape.left + sprite->GetTexture()->GetWidth() / 5, m_Shape.bottom + sprite->GetTexture()->GetHeight() } );
			}
			else
			{
				m_pApple->SetSpawnPoint( Point2f{ m_Shape.left, m_Shape.bottom + sprite->GetTexture()->GetHeight() } );
			}
			--m_AppleAmount;
			m_pApple->SetActive( true );
		}
	}
}

//normal jump
void Avatar::JumpInput( float elapsedSec, const Level* level )
{
	const Uint8* pStates = SDL_GetKeyboardState( nullptr );
	if (level->IsOnGround( m_Shape, m_Velocity ))
	{
		if (pStates[SDL_SCANCODE_SPACE])
		{
			m_ActionState = ActionsState::runningJump;
			m_Velocity.y = m_HighJumpSpeed;
		}
	}
}

//if the current state doesnt equal to the previous state then reset the previous state animation 
void Avatar::ChangeState( ActionsState actionState )
{
	if (m_ActionState == actionState)
		return;
	m_ActionState = actionState;
	m_pIdleSprite->ResetAnimation();
	m_pRunningSprite->ResetAnimation();
	m_pRunningJumpSprite->ResetAnimation();
	m_pLookUpSprite->ResetAnimation();
	m_pAppleThrowSprite->ResetAnimation();
	m_pClimbingSprite->ResetAnimation();
	m_pCrouchSprite->ResetAnimation();
	m_pSlashSprite->ResetAnimation();
	m_pMonkeyBarsMovingSprite->ResetAnimation();
	m_pAppleCrouch->ResetAnimation();
	m_pJumpingAppleSprite->ResetAnimation();
	m_pJumpingSlashSprite->ResetAnimation();
	m_pMonkeyBarsIdleSprite->ResetAnimation();
	m_pNormalJumpSprite->ResetAnimation();

	m_pAladdinHurt->ResetAnimation();
	m_pMonkeyBarsAppleSprite->ResetAnimation();
	m_pMonkeyBarsSlashSprite->ResetAnimation();
	m_pRopeJumpSprite->ResetAnimation();
	m_pRunningStopSprite->ResetAnimation();
	m_pSlashCrouchSprite->ResetAnimation();

	m_pLandingSprite->ResetAnimation();
	m_pGreatLanding->ResetAnimation();

}

Rectf Avatar::GetSwordShape()const
{
	return m_SwordShape;
}

void Avatar::UpdateSwordPosition()
{
	
	float weaponWidth{ m_Shape.width / 2.f };
	float weaponPos{ m_Shape.left + weaponWidth };
	//if in the other direction put the weapon on the left side
	if (m_Direction == -1)
	{
		weaponPos = m_Shape.left;
	}
	m_SwordShape.width = weaponWidth;
	m_SwordShape.left = weaponPos;
	m_SwordShape.bottom = m_Shape.bottom + m_Shape.height / 2.f - 10.f;

}



