#include "pch.h"
#include "Projectile.h"
#include <Texture.h>
#include <iostream>

Projectile::Projectile( const std::string& filePath, const Point2f& startPos )
	:m_Position{ startPos }
	, m_Velocity{ 350,100 }
	, m_Acceleration{ 0,-981.0f }
	, m_SpawnPoint{startPos}
	, m_IsActive{ false }
	, m_Direction{1}
{
	m_pProjectileTexture = new Texture( filePath );
	m_Shape = Rectf{ m_Position.x,m_Position.y, m_pProjectileTexture->GetWidth(), m_pProjectileTexture->GetHeight() };
}
Projectile::~Projectile()
{
	delete m_pProjectileTexture;
}

void Projectile::Update( float elapsedSec )
{
	//update if the object is thrown and not on the ground

	if (m_IsActive)
	{
		m_Velocity.y += m_Acceleration.y * elapsedSec;
		m_Shape.left += m_Velocity.x * elapsedSec*m_Direction;
		m_Shape.bottom += m_Velocity.y * elapsedSec;

	}

}

void Projectile::Draw()const
{
	m_pProjectileTexture->Draw( Rectf{ m_Shape.left,m_Shape.bottom,0,0 } );
}

void Projectile::SetActive( const bool& isActive )
{
	if (isActive)
	{
		m_Shape.left = m_SpawnPoint.x;
		m_Shape.bottom = m_SpawnPoint.y;
	}
	else
	{
		ResetVelocity();
	}
	m_IsActive = isActive;
}

bool Projectile::GetActive()const
{
	return m_IsActive;
}

Point2f Projectile::GetPostition()const
{
	return Point2f{m_Shape.left,m_Shape.bottom};
}

Vector2f Projectile::GetVelocity()const
{
	return m_Velocity;
}

Rectf Projectile::GetProjectileShape() const
{
	return m_Shape;
}

void Projectile::SetSpawnPoint( const Point2f& spawnPoint )
{
	m_SpawnPoint = spawnPoint;
}

void Projectile::ResetVelocity()
{
	m_Velocity.x = 350;
	m_Velocity.y = 100;
}

void Projectile::SetDirection( const int& direction )
{
	m_Direction = direction;
}
