#pragma once
#include "Enemy.h"
class Health;
class Avatar;
class Sprite;
class TextureManager;

class Stickman final : public Enemy
{
public:
	Stickman( Point2f startPos, Avatar* avatar, TextureManager* textureManager, Camera* camera );
	~Stickman();
	Stickman( const Stickman& other ) = delete;
	Stickman& operator=( const Stickman& rhs ) = delete;
	Stickman( Stickman&& other ) = delete;
	Stickman& operator=( Stickman&& rhs ) = delete;

	void Update( float elapsedSec );
	void Draw()const ;

private:

	Sprite* m_pWalkingSprite;
	Sprite* m_pHurtSprite;
	Sprite* m_pSlashSprite;
};