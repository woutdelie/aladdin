#pragma once
class Health;
class Projectile;

class Shortman
{
public:
	Shortman( Point2f startPos, Health* health );
	void Update( float elapsedSec );
	void Draw();
private:
	enum class ActionSate
	{
		idle,
		walking,
		throwing, 
		hurt
	};
	Health* m_pHealth;
	Projectile* m_pProjecile;
	Point2f m_Position;
};

