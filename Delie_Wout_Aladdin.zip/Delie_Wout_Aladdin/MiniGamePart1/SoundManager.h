#pragma once
#include <map>

class SoundEffect;
class SoundStream;

class SoundManager
{
public:
	SoundManager() = default;
	~SoundManager();
	SoundManager( const SoundManager& other ) = delete;
	SoundManager& operator=( const SoundManager& rhs ) = delete;
	SoundManager( SoundManager&& other ) = delete;
	SoundManager& operator=( SoundManager&& rhs ) = delete;

	const SoundStream* GetSoundStream( const std::string& filename );
	const SoundEffect* GetSoundEffect( const std::string& filename );

private:
	std::map<std::string, const SoundStream*> m_SoundStreams;;
	std::map<std::string, const SoundEffect*> m_SoundEffects;
};

