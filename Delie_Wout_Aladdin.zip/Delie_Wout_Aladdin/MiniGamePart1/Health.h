#pragma once
class Health
{
public:
	Health( int healthPoints );
	//bool DealDamage(bool IsHit=false)const;
	void TakeDamage();
	int GetHealthPoints()const;
private:
	int m_HealthPoints;

};

