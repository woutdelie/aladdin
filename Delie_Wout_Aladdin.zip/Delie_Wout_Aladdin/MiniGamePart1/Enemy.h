#pragma once
class Health;
class Sprite;
class Avatar;
class Camera;
class Projectile;

class Enemy
{
public:
	Enemy( /*Point2f startPos,*/Rectf shape, Avatar* pavatar, Camera* camera );
	virtual ~Enemy();
	Enemy( const Enemy& other ) = delete;
	Enemy& operator=( const Enemy& rhs ) = delete;
	Enemy( Enemy&& other ) = delete;
	Enemy& operator=( Enemy&& rhs ) = delete;
	virtual void Update( float elapsedSec );
	virtual void Draw() const =0 ;

protected:
	enum class ActionState
	{
		idle,
		walking,
		slash,
		hurt
	};
	ActionState m_ActionState;
	bool m_IsActive;
	
	void CheckAladdinCollision();

	Point2f m_Position;
	Rectf m_Shape;
	Rectf m_HitTriggerShape;
	Camera* m_pCamera;
	Projectile* m_pAladdinProjectile;

	Avatar* m_pAvatar;

private:
	Health* m_pHealth;
	

};

