#pragma once
#include<vector>
#include<Vector2f.h>
class Texture;

class Platform final
{
public:
	Platform(const Point2f& bottomLeft);
	~Platform();
	Platform(const Platform& other) = delete;
	Platform& operator=(const Platform& other) = delete;
	Platform(Platform&& other) = delete;
	Platform& operator=(Platform&& rhs) = delete;

	void Draw()const;
	void HandleCollision(Rectf& actorShape, Vector2f& actorVelocity);
	bool IsOnGround(const Rectf& actorShape, const Vector2f& actorVelocity);
	
private:
	Rectf m_Shape;
	const Point2f m_BottomLeft;
	const Texture* m_pTexture;
	std::vector<Point2f> m_PlatfromVerts;

	//bool ResetPlatformTimer(bool isTimerStarted,float);

};

