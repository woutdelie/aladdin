#pragma once
#include <map>
class Texture;

class TextureManager
{
public:

	TextureManager() = default;
	~TextureManager();
	TextureManager( const TextureManager& other ) = delete;
	TextureManager& operator=( const TextureManager& rhs ) = delete;
	TextureManager( TextureManager&& other ) = delete;
	TextureManager& operator=( TextureManager&& rhs ) = delete;

	const Texture* GetTexture( const std::string& filename );

private:

	std::map<std::string, const Texture*> m_Textures;
	
};

