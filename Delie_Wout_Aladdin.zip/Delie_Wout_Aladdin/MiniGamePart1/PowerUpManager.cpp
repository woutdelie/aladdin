#include "pch.h"
#include "PowerUpManager.h"
#include "utils.h"
#include <SoundEffect.h>

PowerUpManager::PowerUpManager()
	:m_pItems{  }
	, m_pPowerUpHitSound{ new SoundEffect( "Sounds/Apple Collect.WAV" ) }
{
}

PowerUpManager::~PowerUpManager()
{
	for (int index{}; index < m_pItems.size(); ++index)
	{
		delete m_pItems[index];
		m_pItems[index] = nullptr;
	}
	delete m_pPowerUpHitSound;
}

PowerUp* PowerUpManager::AddItem( const Point2f& center, PowerUp::Type type )
{

	PowerUp* powerUp{ new PowerUp( center, type ) };
	m_pItems.push_back( powerUp );
	return powerUp;
}

void PowerUpManager::Update(float elapsedSec)
{
	for (int index{}; index < m_pItems.size(); ++index)
	{
		m_pItems.at(index)->Update(elapsedSec);
	}
}

void PowerUpManager::Draw() const
{
	glPushMatrix();
	{
		for (int index{}; index < m_pItems.size(); ++index)
		{
			m_pItems.at( index )->Draw();
		}
	}
	glPopMatrix();
}

size_t PowerUpManager::Size() const
{
	return m_pItems.size();
}

bool PowerUpManager::HitItem( const Rectf& rect )
{
	for (int index{ int( m_pItems.size() - 1 ) }; index >= 0; --index)
	{
		if (m_pItems.at( index )->IsOverlapping( rect ) == true)
		{
			delete m_pItems[index];
			m_pItems.at( index ) = m_pItems.at( m_pItems.size() - 1 );
			m_pItems.pop_back();
			
			m_pPowerUpHitSound->Play(0);
			return true;
		}

	}
	return false;

}


