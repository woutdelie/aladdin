#pragma once
class Health;
class Swordman
{
public:
	Swordman( Point2f startPos, Health* health );
	void Update( float elapsedSec );
	void Draw();
private:
	enum class ActionState
	{
		walking,
		idle,
		fireHurt,
		lowStab,
		slash,
		hurt
	};
	Health* m_pHealth;
	Point2f m_Position;
};