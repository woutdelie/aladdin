#pragma once
#include "Level.h"
class Sprite;
class Projectile;
class TextureManager;
class SoundEffect;
class SoundManager;
class Health;

class Avatar final
{
public: 
	Avatar(TextureManager* textureManager, SoundManager* soundManager );
	~Avatar();
	Avatar(const Avatar& other) = delete;
	Avatar& operator=(const Avatar& rhs) = delete;
	Avatar(Avatar&& other) = delete;
	Avatar& operator=(Avatar&& rhs) = delete;
	
	enum class ActionsState
	{
		idle,
		running,
		hurt,
		slash,
		crouch,
		runningStop,
		appleThrow,
		normalJump,
		runningJump,
		jumpingApple,
		jumpingSlash,
		landing,
		greatLanding,
		climbing,
		lookUp,
		appleCrouch,
		slashCrouch,
		monkeybarsMoving,
		monkeybarsIdle,
		monkeybarApple,
		monkeybarsSlash,
		ropeJump,
		fire,
	};

	void Update(float elapsedSec, const Level* level);
	void Draw()const;
	void PowerUpHit();
	int GetAppleAmount()const;
	Rectf GetShape()const;

	Rectf GetAppleShape()const;
	Projectile* GetProjectile()const;

	bool GetSlashState()const;
	Rectf GetSwordShape()const;


private:

	Point2f m_StartPos;
	Rectf m_Shape;
	Rectf m_SwordShape;
	const float m_HighJumpSpeed;
	Vector2f m_Velocity;
	Vector2f m_Acceleration;
	ActionsState m_ActionState;
	//float m_AccuTransformSec;
	//const float m_MaxTransformSec;
	//int m_Power;
	int m_Direction;
	Health* m_pHealth;

	const float m_HorSpeed;
	const float m_SmallJumpSpeed;
	float m_JumpTimer;

	Projectile* m_pApple;
	Point2f m_ApplePos;
	int m_AppleAmount;
	bool m_AppleHit;
	Vector2f m_AppleVelocity;

	Sprite* m_pIdleSprite;
	Sprite* m_pRunningSprite;
	Sprite* m_pRunningJumpSprite;
	Sprite* m_pLookUpSprite;
	Sprite* m_pAppleThrowSprite;
	Sprite* m_pCrouchSprite;
	Sprite* m_pSlashSprite;
	Sprite* m_pClimbingSprite;
	
	Sprite* m_pMonkeyBarsMovingSprite;
	Sprite* m_pAppleCrouch;
	Sprite* m_pAladdinHurt;
	Sprite* m_pRunningStopSprite;
	Sprite* m_pJumpingAppleSprite;
	Sprite* m_pJumpingSlashSprite;

	Sprite* m_pMonkeyBarsIdleSprite;
	Sprite* m_pMonkeyBarsAppleSprite;
	Sprite* m_pMonkeyBarsSlashSprite;
	Sprite* m_pRopeJumpSprite;
	Sprite* m_pSlashCrouchSprite;
	Sprite* m_pNormalJumpSprite;
	Sprite* m_pLandingSprite;
	Sprite* m_pGreatLanding;

	bool m_IsPressedOnce;
	const SoundEffect* m_pHighSlash;

	//const Texture* m_pFire;

	void InputActions(float elapsedSec, const Level* level);
	void ChangeState( ActionsState actionState );

	void JumpInput( float elapsedSec, const Level* level );

	void UpdateApple(float elapsedSec, const Level* level);
	void AppleThrow( const Sprite* sprite );
	
	void UpdateSwordPosition();
};

