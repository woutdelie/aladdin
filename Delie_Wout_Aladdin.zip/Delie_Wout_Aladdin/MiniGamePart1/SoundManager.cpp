#include "pch.h"
#include "SoundManager.h"
#include <SoundEffect.h>
#include <SoundStream.h>

SoundManager::~SoundManager()
{
    std::map<std::string, const SoundStream*>::iterator itSoundStream = m_SoundStreams.begin();
    
    while (itSoundStream != m_SoundStreams.end())
    {
        delete itSoundStream->second;
        ++itSoundStream;
    }
    m_SoundStreams.clear();


    std::map<std::string, const SoundEffect*>::iterator itSoundEffects = m_SoundEffects.begin();
    
    while (itSoundEffects != m_SoundEffects.end())
    {
        delete itSoundEffects->second;
        ++itSoundEffects;
    }
    m_SoundEffects.clear();
}

const SoundStream* SoundManager::GetSoundStream( const std::string& filename )
{
    std::map<std::string, const SoundStream*>::iterator iterator{ m_SoundStreams.find( filename ) };

    if (iterator == m_SoundStreams.end())
    {
        const SoundStream* pSoundStream{ new SoundStream( filename ) };
        m_SoundStreams[filename] = pSoundStream;
        return pSoundStream;
    }

    return iterator->second;
}

const SoundEffect* SoundManager::GetSoundEffect( const std::string& filename )
{
    std::map<std::string, const SoundEffect*>::iterator iterator{ m_SoundEffects.find( filename ) };

    if (iterator == m_SoundEffects.end())
    {
        const SoundEffect* pSoundEffect{ new SoundEffect( filename ) };
        m_SoundEffects[filename] = pSoundEffect;
        return pSoundEffect;
    }

    return iterator->second;
}
