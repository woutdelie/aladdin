#include "pch.h"
#include "Sprite.h"
#include <Texture.h>
#include "TextureManager.h"

Sprite::Sprite( const std::string& filePath, int nrOfFrames, int nrFramesPerSecond, TextureManager* textureManager, bool isLooping ) 
	: m_NrOfFrames{ nrOfFrames }
	, m_NrFramesPerSec{ nrFramesPerSecond }
	, m_AnimTime{}
	, m_AnimFrame{}
	, m_Direction{ 1 }
	, m_IsFinished{ false }
	, m_IsLooping{ isLooping }
	, m_CurrFrame{}
{
	m_pSpriteTexture = textureManager->GetTexture( filePath );
	m_ClipWidth = m_pSpriteTexture->GetWidth() / m_NrOfFrames;
	m_ClipHeight = m_pSpriteTexture->GetHeight();

}

//Sprite::~Sprite()
//{
//	//delete m_pSpriteTexture;
//}

void Sprite::Update( float elapsedSec )
{
	//if the animation doesnt need to loop and has done it once return
	if (!m_IsLooping && m_IsFinished)
		return;

	m_AnimTime += elapsedSec;
	const float maxTime{ 1.f / m_NrFramesPerSec };
	if (m_AnimTime > maxTime)
	{
		if (!m_IsLooping && m_CurrFrame == m_NrOfFrames - 1 && m_AnimTime >= maxTime)
		{
			m_IsFinished = true;
			return;
		}

		//m_AnimFrame = (m_AnimFrame + 1) % m_NrOfFrames;
		m_AnimTime = 0;
		++m_CurrFrame;
		if (m_CurrFrame >= m_NrOfFrames)
		{
			m_CurrFrame = 0;
			m_IsFinished = false;
		}
	}
}

void Sprite::Draw(const Rectf& shape )const
{
	Rectf srcRect{ m_ClipWidth * m_CurrFrame,m_ClipHeight,m_ClipWidth,m_ClipHeight };
	glPushMatrix();
	{
		glTranslatef( shape.left, shape.bottom, 0 );
		
		if (m_Direction == -1)
		{
			glScalef( -1, 1, 1 );
			glTranslatef( -m_ClipWidth, 0, 0 );
		}
		m_pSpriteTexture->Draw( Point2f{  }, srcRect );
		
	}
	glPopMatrix();
}

void Sprite::Draw(const Point2f& pos )const
{
	Draw( Rectf{ pos.x,pos.y,m_ClipWidth,m_ClipHeight } );
}

void Sprite::ResetAnimation()
{
	m_CurrFrame = 0;
	m_IsFinished = false;
	m_AnimTime = 0;
}

void Sprite::SetDirection( const int& direction )
{
	m_Direction = direction;
}

const Texture* Sprite::GetTexture() const
{
	return m_pSpriteTexture;
}

int Sprite::GetNrOfFrames()const
{
	return m_NrOfFrames;
}
