#pragma once

class Texture;


class PowerUp final
{
public:
	enum class Type
	{
		health,
		apple,
		diamond,
		fenieBottle,
		extraLife,
		genieBonus,
		abuBonus
	};
	explicit PowerUp(const Point2f& center, PowerUp::Type type);
	PowerUp(const PowerUp& other) = delete;
	PowerUp& operator=(const PowerUp& rhs)=delete;
	PowerUp(PowerUp&& other) = delete;
	PowerUp& operator=(PowerUp&& rhs) = delete;
	~PowerUp();
	void Update(float elapsedSec);
	void Draw() const;
	bool IsOverlapping(const Rectf& rect) const;
	Type GetType()const;

private:
	const Type m_Type;
	const Texture* m_pAppleTexture;
	const Texture* m_pGenieBottleTexture;
	const Texture* m_pGenieTexture;
	const float m_RotSpeed;
	Rectf m_TextClip;
	Circlef m_Shape;
	float m_Angle;
};

