#include "pch.h"
#include "TextureManager.h"
#include <Texture.h>

TextureManager::~TextureManager()
{
    std::map<std::string, const Texture*>::iterator it = m_Textures.begin();
    while (it != m_Textures.end())
    {
        delete it->second;
        ++it;
    }

    m_Textures.clear();


}

const Texture* TextureManager::GetTexture ( const std::string& filename )
{
    std::map<std::string, const Texture*>::iterator iterator{ m_Textures.find( filename ) };

    if (iterator == m_Textures.end())
    {
        const Texture* pTexture{ new Texture(filename) };
        m_Textures[filename] = pTexture;
        return pTexture;
    }

    return iterator->second;
}
