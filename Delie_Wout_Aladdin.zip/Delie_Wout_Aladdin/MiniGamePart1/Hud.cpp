#include "pch.h"
#include "Hud.h"
#include <Texture.h>
#include <iostream>
#include "Avatar.h"
#include "Sprite.h"

Hud::Hud( const Point2f& topLeft, int totalPowerUps, Avatar* pAvatar, TextureManager* textureManager )
	: m_BottomLeft{ topLeft }
	//, m_TotalPowerUps{ totalPowerUps }
	, m_HitPowerUps{10}
	,m_pAvatar{pAvatar}
	, m_pLives{ new Texture( "Images/life.png" ) }
	, m_pApples{ new Texture( "Images/hudApple.png" ) }
	, m_pNumbers{ new Texture( "Images/font.png" ) }
{
	m_pHealth8 = new Sprite( "Images/health8.png", 4, 12, textureManager );
}
Hud::~Hud()
{
	delete m_pLives;
	delete m_pApples;
	delete m_pNumbers;
	delete m_pHealth8;
}
void Hud::Draw()const
{	
	int appletotal{ m_pAvatar->GetAppleAmount() };
	float clipwidth{ m_pNumbers->GetWidth() / 10 };
	int tientallen{ appletotal / 10 };
	int resten{ appletotal % 10 };
	float offset{ 20.f };
	glPushMatrix();
	{
		glScalef( 1.3f, 1.3f, 1.f );
		m_pLives->Draw( Rectf{ m_BottomLeft.x,m_BottomLeft.y-10,0,0 }, Rectf{ 0,0,m_pLives->GetWidth(),m_pLives->GetHeight() } );
		m_pApples->Draw( Rectf{ m_BottomLeft.x+500,m_BottomLeft.y,0,0 }, Rectf{ 0,0,m_pApples->GetWidth(),m_pApples->GetHeight() } );
		m_pHealth8->Draw(Point2f{m_BottomLeft.x-offset, m_BottomLeft.y+280});
	}
	glPopMatrix();

	glPushMatrix();
	{
		glScalef( 2.f, 2.f, 1.f );
		m_pNumbers->Draw( Rectf{ m_BottomLeft.x + m_pLives->GetWidth() - offset,m_BottomLeft.y - offset,0,0 }, Rectf{ clipwidth * 3,0,clipwidth ,m_pNumbers->GetHeight() } );
		m_pNumbers->Draw( Rectf{ m_BottomLeft.x + 340,m_BottomLeft.y - offset,0,0 }, Rectf{ clipwidth * tientallen,0,clipwidth ,m_pNumbers->GetHeight() } );
		m_pNumbers->Draw( Rectf{ m_BottomLeft.x + 360,m_BottomLeft.y - offset,0,0 }, Rectf{ clipwidth * resten,0,clipwidth ,m_pNumbers->GetHeight() } );
	}
	glPopMatrix();

}
void Hud::Update( float elapsedSec )
{
	m_pHealth8->Update( elapsedSec );
}
void Hud::PowerUpHit()
{
	
	++m_HitPowerUps;
	//std::cout << m_HitPowerUps;
}

void Hud::SetTopLeft( const Point2f& newPos )
{
	m_BottomLeft = newPos;
}
