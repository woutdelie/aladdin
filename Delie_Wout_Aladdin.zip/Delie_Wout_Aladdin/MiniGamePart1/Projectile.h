#pragma once
#include <Vector2f.h>
class Texture;
class Projectile final
{
public:
	Projectile(const std::string& filePath,const Point2f& startPos);
	~Projectile();
	Projectile (const Projectile& other)=delete;
	Projectile& operator=(const Projectile& rhs)=delete;
	Projectile(Projectile&& other) = delete;
	Projectile& operator=(Projectile&& rhs) = delete;
	
	void Update(float elapsedSec);
	void Draw()const;

	void SetActive(const bool& isActive);

	bool GetActive()const;
	Point2f GetPostition()const;
	Vector2f GetVelocity()const;
	Rectf GetProjectileShape()const;

	void SetSpawnPoint(const Point2f& spawnPoint);
	void ResetVelocity();
	void SetDirection( const int& direction );


private:
	const Texture* m_pProjectileTexture;
	Point2f m_Position;
	Vector2f m_Acceleration;
	Vector2f m_Velocity;
	bool m_IsActive;
	Point2f m_SpawnPoint;
	int m_Direction;
	Rectf m_Shape;
	

};

