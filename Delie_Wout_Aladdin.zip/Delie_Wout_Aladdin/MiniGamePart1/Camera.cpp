#include "pch.h"
#include "Camera.h"
#include <utils.h>

Camera::Camera( float width, float height )
	: m_Width{ width }
	, m_Height{ height }
	, m_LevelBoundaries{ Rectf{0,0,width,height} }
	, m_CameraShape{ Rectf{0,0,0,0} }

{
}

void Camera::SetLevelBoundaries( const Rectf& levelBoundaries )
{
	m_LevelBoundaries = levelBoundaries;
}
//draws the camera 
void Camera::Transform( const Rectf& target )
{
	/*Rectf zoomedTarget{ target.left, target.bottom,target.width,target.height  };*/
	Point2f cameraPos{ Track( target ) };
	Clamp( cameraPos );

	m_CameraShape.left = cameraPos.x;
	m_CameraShape.bottom = cameraPos.y;
	m_CameraShape.width = m_Width;
	m_CameraShape.height = m_Height;

	utils::SetColor( Color4f{ 0,0,1,1 } );
	//glScalef(zoom, zoom, 1.0f);
	utils::DrawRect(cameraPos, m_Width, m_Height);
	glTranslatef( -cameraPos.x, -cameraPos.y, 0 );

}
Rectf Camera::GetCameraShape() const
{
	return m_CameraShape;
}
//makes the camera place around the target
Point2f Camera::Track( const Rectf& target )const
{

	return Point2f( (target.left + target.width / 2.0f - m_Width / 2.0), (target.bottom + target.height / 2.f - m_Height / 2.f) );

}
//make sure not to leave the level boundaries
void Camera::Clamp( Point2f& bottomLeftPos )const
{
	if (bottomLeftPos.x < m_LevelBoundaries.left)
		bottomLeftPos.x = m_LevelBoundaries.left;

	else if (bottomLeftPos.x + m_Width > m_LevelBoundaries.left + m_LevelBoundaries.width+50.f)
		bottomLeftPos.x = (m_LevelBoundaries.left + m_LevelBoundaries.width+50.f - m_Width);

	if (bottomLeftPos.y < m_LevelBoundaries.bottom)
		bottomLeftPos.y = m_LevelBoundaries.bottom;

	else if (bottomLeftPos.y + m_Height > m_LevelBoundaries.bottom + m_LevelBoundaries.height)
		bottomLeftPos.y = (m_LevelBoundaries.bottom + m_LevelBoundaries.height - m_Height);
}
